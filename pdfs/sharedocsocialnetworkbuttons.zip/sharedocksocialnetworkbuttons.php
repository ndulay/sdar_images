<?php
/**
 * @version		1.0
 * @Project		Share Dock Social Network Buttons
 * @author 		Zasha M., eShiok.com
 * @package		
 * @copyright	Copyright (C) 2011 eShiok.com. All rights reserved.
 * @license 	http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin');

class plgSystemsharedocksocialnetworkbuttons extends JPlugin
{
	function plgSystemsharedocksocialnetworkbuttons(&$subject, $config)
	{
		parent::__construct($subject, $config);		
	}
	
	function onAfterRender()
	{
		$app = JFactory::getApplication();

		$background_color = $this->params->get('background_color');
		if($app->isAdmin() === true || strpos($_SERVER["PHP_SELF"], "index.php") === false)
		{
			return;
		}

		$buffer = JResponse::getBody();

		$htmlCodes = "\n";
		$imageURL = JURI::base() . "plugins/system/sharedocksocialnetworkbuttons";
		$jsURL = JURI::base() . "plugins/system/sharedocksocialnetworkbuttons";
		$currentPath = JURI::current();
		//http://icondock.com/free/vector-social-media-icons
		//$document =& JFactory::getDocument();  
        //$document->addScript(JURI::base() . 'plugins/content/sharedocksocialnetworkbuttons/js/fisheye-iutil.min.js');
	
		$htmlCodes .= "<style type=\"text/css\"> \n";
		if (strlen($background_color ) > 2) {
			$htmlCodes .= "body { background: $background_color; }\n";
		}
		 
		$htmlCodes .= "#sharedock { position: fixed; bottom: 0; left: 0; width: 100%; height: 90px; z-index: 999; }\n";
		$htmlCodes .= "#dock { position: relative; bottom: 0; font: 13px \"Trebuchet MS\", Verdana, Helvetica, sans-serif; }\n";
		$htmlCodes .= ".dock-container { position: relative; background: url(http://www.addthis.com/cms-content/images/gallery/dock-background-sm.png) no-repeat bottom right; height: 50px; padding: 20px; }\n";
		$htmlCodes .= ".dock-contaner-left { background: url(http://www.addthis.com/cms-content/images/gallery/dock-background-sm.png) no-repeat left bottom; width: 15px; height: 32px; position: absolute; bottom: 0; left: -15px; }\n";
		$htmlCodes .= ".dock-container .custom_images a { display: block; width: 50px; position: absolute; bottom: 0; text-align: center; text-decoration: none; color: #333; cursor: pointer; }\n";
		$htmlCodes .= ".dock-container .custom_images span { background: rgba(0,0,0,.75); display: none; padding: 2px 8px; margin-left: 17px; font-size: 11px; color: #fff; -moz-border-radius: 10px; -webkit-border-radius: 10px; }\n";
		$htmlCodes .= ".dock-container .custom_images img { border: 0; margin: 5px 10px 0px; width: 100%; }\n";
		$htmlCodes .= "</style> \n";
		$htmlCodes .= "<div id=\"sharedock\"> \n";
		$htmlCodes .= "	<div id=\"dock\"> \n";
		$htmlCodes .= "		<div class=\"dock-container\">	\n";	
		$htmlCodes .= "			<div class=\"dock-contaner-left\"></div> \n";
		$htmlCodes .= "			<div class=\"addthis_toolbox\">  \n"; 
		$htmlCodes .= "				<div class=\"custom_images\"> \n";
		$htmlCodes .= "					<a class=\addthis_button_facebook\"><span>Facebook</span><img src=\"http://www.addthis.com/cms-content/images/gallery/aquaticus_facebook.png\" alt=\"Share to Facebook\" /></a> \n";
		$htmlCodes .= "					<a class=\"addthis_button_twitter\"><span>Twitter</span><img src=\"http://www.addthis.com/cms-content/images/gallery/aquaticus_twitter.png\" alt=\"Share to Twitter\" /></a> \n";
		$htmlCodes .= "					<a class=\"addthis_button_myspace\"><span>MySpace</span><img src=\"http://www.addthis.com/cms-content/images/gallery/aquaticus_myspace.png\" alt=\"Share to MySpace\" /></a> \n";
		$htmlCodes .= "					<a href=\"http://www.eshiok.com/component/option,com_ibook/owner,eshiok/Itemid,99999999/func,sign/\"><span>My iBook</span><img src=\"$imageURL/myibook.png\" alt=\"Share to My iBook\" /></a>\n";
		$htmlCodes .= "					<a class=\"addthis_button_stumbleupon\"><span>Stumble</span><img src=\"http://www.addthis.com/cms-content/images/gallery/aquaticus_stumbleupon.png\" alt=\"Stumble It\" /></a> \n";
		$htmlCodes .= "					<a href=\"http://cmsvoteup.com/index.php?page=submit1&url=$currentPath\"><span>Vote Up</span><img src=\"$imageURL/favorites.png\" alt=\"CMS Vote Up\" /></a>\n";
		$htmlCodes .= "					<a class=\"addthis_button_reddit\"><span>Reddit</span><img src=\"http://www.addthis.com/cms-content/images/gallery/aquaticus_reddit.png\" alt=\"Share to Reddit\" /></a> \n";
		//$htmlCodes .= "					<a class=\"addthis_button_delicious\"><span>Delicious</span><img src=\"http://www.addthis.com/cms-content/images/gallery/aquaticus_delicious.png\" alt=\"Share to Delicious\" /></a> \n";
		
		$htmlCodes .= "					<a class=\"addthis_button_more\"><span>More...</span><img src=\"http://www.addthis.com/cms-content/images/gallery/addthis_64.png\" alt=\"More...\" /></a> \n";
		$htmlCodes .= "				</div> \n";
		$htmlCodes .= "			</div>   \n";     
		$htmlCodes .= "		</div> \n";
		$htmlCodes .= "	</div> \n";
		$htmlCodes .= "</div> \n";
		 
		 
		$htmlCodes .= "<script type=\"text/javascript\" src=\"http://s7.addthis.com/js/250/addthis_widget.js\"></script> \n";
		$htmlCodes .= "<script type=\"text/javascript\" src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js\"></script> \n";
		$htmlCodes .= "<script type=\"text/javascript\" src=\"http://www.addthis.com/cms-content/images/gallery/fisheye-iutil.min.js\"></script> \n";
		//$htmlCodes .= "<script type=\"text/javascript\" src=\"$jsURL/fisheye-iutil.min.js\"></script> \n";
		
		$htmlCodes .= "<script type=\"text/javascript\"> \n";
		$htmlCodes .= "$(function () { \n";
		$htmlCodes .= "	// Dock initialize\n";
		$htmlCodes .= "	$('#dock').Fisheye(\n";
		$htmlCodes .= "		{\n";
		$htmlCodes .= "			maxWidth: 30,\n";
		$htmlCodes .= "			items: 'a',\n";
		$htmlCodes .= "			itemsText: 'span',\n";
		$htmlCodes .= "			container: '.dock-container',\n";
		$htmlCodes .= "			itemWidth: 50,\n";
		$htmlCodes .= "			proximity: 60,\n";
		$htmlCodes .= "			alignment : 'left',\n";
		$htmlCodes .= "			valign: 'bottom',\n";
		$htmlCodes .= "			halign : 'center'\n";
		$htmlCodes .= "		}\n";
		$htmlCodes .= "	);\n";
		$htmlCodes .= "});\n";
		$htmlCodes .= "</script>   \n";

		$pos = strrpos($buffer, "</body>");
		
		if($pos > 0)
		{
			$buffer = substr($buffer, 0, $pos).$htmlCodes.substr($buffer, $pos);

			JResponse::setBody($buffer);
		}
		
		return true;
	}
}
?>
